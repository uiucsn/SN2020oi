template format:

time since g_max, color, uncertainty
