template format:

time since Vmax, color, uncertainty
