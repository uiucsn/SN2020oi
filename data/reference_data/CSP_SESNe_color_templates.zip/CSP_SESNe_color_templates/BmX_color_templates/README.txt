template format:

time since Bmax, color, uncertainty
