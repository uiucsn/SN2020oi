template format:

time since r_max, color, uncertainty
